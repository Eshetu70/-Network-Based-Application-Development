const express =require('express');
const controller =require('../controllers/eventController')
const {fileUpload} = require('../middlewares/fileUpload');

const {isLoggedIn, isAuthor} =require('../middlewares/auth')

const {validateId} =require('../middlewares/validator')

const router =express.Router();

router.get('/',controller.index);

router.get('/new',  isLoggedIn, controller.new);

//post

router.post('/',  isLoggedIn, fileUpload, controller.create);

router.get('/:id', validateId, controller.show);

//updated
router.get('/:id/edit', isLoggedIn, validateId, isAuthor, controller.edit);

//put

router.put('/:id', isLoggedIn, validateId, isAuthor, fileUpload,controller.update);

//delete
router.delete('/:id',  isLoggedIn, validateId, isAuthor,controller.delete);


module.exports =router;