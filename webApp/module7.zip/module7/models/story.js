const { DateTime } = require("luxon");
const {v4: uuidv4} = require('uuid');
const {ObjectId} = require('mongodb');


///Stories collection in mongodb
let student;
exports.getCollection = db=>{
    student =db.collection('student');
}

exports.find = () => student.find().toArray();

exports.findById = id => student.findOne({_id: new ObjectId(id)});

exports.save = story=> student.insertOne(story);
    

exports.updateById = (id, newStory)=> student.updateOne({_id: new ObjectId(id)},{$set:{firstName: newStory.firstName, lastName: newStory.lastName, degree: newStory.degree, concentration: newStory.concentration }});

exports.deleteById = function(id) {
    let index = stories.findIndex(story =>story.id === id);
    if(index !== -1) {
        stories.splice(index, 1);
        return true;
    } else {
        return false;
    }
}