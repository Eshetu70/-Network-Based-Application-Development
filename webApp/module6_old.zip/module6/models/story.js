

const { DateTime } = require("luxon");
const stories =[
    {id:'1',
    title:'My life at Charlotte',
    author:'Eshetu Wekjira',
    content: 'I have been live charlotte for five years, and I love to be here in charlotte; charlotte is such a quiet city so far, I see, and it is the place I would love to live.',
    createdAt:DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },

    {
        id:'2',
        title:'Learning NBAD',
        author:'Eshetu Wekjira',
        content:'The National Basketball Association (NBA) is a professional basketball league in North America. The league is composed of 30 teams (29 in the United States and 1 in Canada) and is one of the major professional sports leagues in the United States and Canada.',
       
        createdAt:DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)

    },
    {
        id:'3',
        title:'My Spring Break',
        author:'Eshetu Wekjira',
        content:'During my spring break, I had a great time with my family members and developed a website page for Community Kitchen Program.',
        createdAt:DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)

    }
];

exports.find =()=>stories;

 exports.findById =function(id){

 return stories.find(story=>story.id ==id);
 };

//console.log(stories[1]);