

const ejs = require('ejs');
// const express =require('express');
// const router =express.Router();
// const { v4: uuidv4 } = require('uuid');

//GET /stories : send all storiess

const model =require('../models/story');

exports.index = (req, res)=>{
    //res.send('send all stories');
    //res.send(model.find());
    let stories = model.find();
    res.render('./story/index.ejs',{stories});
};

//GET /Stories/new send html form for creating new stories
exports.new=(req, res)=>{
    res.send('Send new form')
};
//POST /stories: create new stories
exports.create=(req, res)=>{
   res.send('create new stories') 
};
//GET /stories/:id: send detials of

exports.show = (req, res)=>{
    // res.send('send all stories with id: '+ req.params.id);
  let id =req.params.id;
  let story =model.findById(id);
  if(story){
    res.render('./story/show.ejs',{story});
  }
  res.status(404).send('Cannot find story with id:' + id)
};


//Get /Stories/:id/edit: send the html form for editing

exports.edit=(req, res)=>{
    res.send('Edit form');

};

//PUT /stories/:id: update the story identified by id

exports.update =(req, res)=>{
    res.send('updated stories with id: ' + req.params.id);

};

//Delete  /stories/:id, delete the story identified by id
exports.delete=(req, res)=>{
    res.send('delete stories with id: ' + req.params.id);

};


