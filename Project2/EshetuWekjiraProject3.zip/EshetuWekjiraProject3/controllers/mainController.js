


exports.index =(req, res)=>{
    res.render('index.ejs');

};

exports.about= (req, res) => {
    res.render('about.ejs')
};

exports.contact = (req, res) => {
    res.render('contact.ejs')

};

